import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class User {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ type: "text" })
  role: "freelancer" | "company" | "admin";

  @Column({ type: "text" })
  name: string;

  @Column({ type: "text", unique: true })
  email: string;

  @Column({ type: "text" })
  phone: string;

  @Column({ type: "text" })
  hashed_password: string;

  @Column({ type: "text", nullable: true })
  profile_picture: string;

  @Column({ type: "text", nullable: true })
  bio: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}

@Entity()
export class Job {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ type: "uuid" })
  company_id: string;

  @Column({ type: "text" })
  title: string;

  @Column({ type: "text" })
  description: string;

  @Column({ type: "double precision" })
  lat: number;

  @Column({ type: "double precision" })
  lng: number;

  @Column({ type: "text" })
  address: string;

  @Column({ type: "timestamptz" })
  start_time: Date;

  @Column({ type: "timestamptz" })
  end_time: Date;

  @Column({ type: "numeric" })
  pay_amount: number;

  @Column({ type: "text", default: "published" })
  status: string;

  @CreateDateColumn()
  created_at: Date;
}

@Entity()
export class AttendanceLog {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ type: "uuid" })
  job_id: string;

  @Column({ type: "uuid" })
  freelancer_id: string;

  @Column({ type: "double precision" })
  checkin_lat: number;

  @Column({ type: "double precision" })
  checkin_lng: number;

  @Column({ type: "timestamptz", nullable: true })
  checkin_time: Date;

  @Column({ type: "timestamptz", nullable: true })
  checkout_time: Date;

  @Column({ type: "text", default: "not_checked_in" })
  status: string;
}