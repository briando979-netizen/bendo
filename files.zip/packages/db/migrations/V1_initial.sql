CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  role text NOT NULL,
  name text,
  email text UNIQUE NOT NULL,
  phone text,
  hashed_password text NOT NULL,
  profile_picture text,
  bio text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE jobs (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id uuid NOT NULL,
  title text,
  description text,
  lat double precision,
  lng double precision,
  address text,
  start_time timestamptz,
  end_time timestamptz,
  pay_amount numeric,
  status text DEFAULT 'published',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE attendance_logs (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id uuid NOT NULL,
  freelancer_id uuid NOT NULL,
  checkin_lat double precision,
  checkin_lng double precision,
  checkin_time timestamptz,
  checkout_time timestamptz,
  status text DEFAULT 'not_checked_in'
);