import request from 'supertest';
import app from '../src/app';

describe('Auth', () => {
  it('should register and login', async () => {
    const user = { email: "test@example.com", password: "123456", role: "freelancer", name: "Test User", phone: "1234567890" };
    await request(app).post('/auth/register').send(user).expect(200);
    const res = await request(app).post('/auth/login').send({ email: user.email, password: user.password }).expect(200);
    expect(res.body.access_token).toBeDefined();
  });
});