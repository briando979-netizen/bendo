import { FastifyInstance } from "fastify";
import { isWithinGeofence } from "packages/shared/haversine";
import { User, Job, AttendanceLog } from "packages/db/entities";
// ... imports, JWT middleware, database setup

export default async function (fastify: FastifyInstance) {
  // Auth
  fastify.post("/auth/register", async (req, res) => { /* create user + hash password */ });
  fastify.post("/auth/login", async (req, res) => { /* verify user + return JWT */ });
  fastify.post("/auth/refresh", async (req, res) => { /* refresh JWT */ });

  // Jobs
  fastify.post("/jobs", { preHandler: [requireAuth] }, async (req, res) => { /* company post job */ });
  fastify.get("/jobs", async (req, res) => { /* filter jobs */ });
  fastify.get("/jobs/:id", async (req, res) => { /* job detail */ });

  // GPS Checkin
  fastify.post("/jobs/:id/checkin", { preHandler: [requireAuth] }, async (req, res) => {
    // Validate freelancer assignment, check geofence (haversine)
    // Record AttendanceLog, update status
  });

  // No-Show Detectie (stub, worker zou dit elke X minuten runnen)
  fastify.post("/jobs/:id/no-show/detect", async (req, res) => {
    // Controleer of assigned freelancer is niet ingecheckt binnen grace_period
    // Maak no_show_events record aan (nog niet geïmplementeerd)
  });
}