import React from 'react';
import { View, Text, Button } from 'react-native';

export default function App() {
  return (
    <View>
      <Text>Klushub Mobile</Text>
      <Button title="Check-in" onPress={() => {/* GPS flow */}} />
    </View>
  );
}