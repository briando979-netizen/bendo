import { useRouter } from 'next/router';
export default function Checkin() {
  const router = useRouter();
  // ... GPS-permission, call /api/jobs/:id/checkin
  return (
    <div>
      <h1>Check-in bij klus</h1>
      <button>Check-in (stuur GPS)</button>
    </div>
  );
}