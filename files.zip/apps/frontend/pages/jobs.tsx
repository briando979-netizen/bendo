import { useEffect, useState } from 'react';
import axios from 'axios';

export default function JobsList() {
  const [jobs, setJobs] = useState([]);
  useEffect(() => { axios.get('/api/jobs').then(res => setJobs(res.data)); }, []);
  return (
    <div>
      <h1>Beschikbare klussen</h1>
      <ul>
        {jobs.map(job => (
          <li key={job.id}>
            <a href={`/jobs/${job.id}`}>{job.title} - {job.address}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}