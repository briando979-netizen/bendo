# Klushub v3.0 MVP

## Features
- Auth (JWT)
- Jobs & GPS Checkin
- No-show detectie (stub)
- Minimal frontend & mobile skeleton

## Development
- `pnpm install`
- `docker-compose up` (dev stack)
- `pnpm run dev` in backend/frontend/mobile

## Deployment
- Backend: AWS EC2/ECS, RDS, S3 (uploads)
- Frontend: Vercel

## API Spec
Zie `openapi.yaml` (Swagger UI via /docs in backend).

## Testing
- `pnpm run test` (unit/integration)